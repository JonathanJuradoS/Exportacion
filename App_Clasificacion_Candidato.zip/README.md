
# 🧠 Clasificación de Candidatos Tecnológicos

Esta aplicación web en Streamlit permite predecir si un candidato sería seleccionado para entrevista, usando un modelo de Machine Learning previamente entrenado.

## 📦 Contenido del paquete

- `app_web_prediccion_candidato.py`: Aplicación Streamlit.
- `modelo_empleo_boosting.pkl`: Modelo entrenado con Gradient Boosting.
- `scaler_empleo_boosting.pkl`: Scaler utilizado para normalizar los datos.

## 🚀 Requisitos

Asegúrate de tener Python instalado. Luego instala las siguientes librerías:

```bash
pip install streamlit scikit-learn pandas joblib
```

## ▶️ Cómo ejecutar la aplicación

1. Descomprime este paquete.
2. Abre una terminal en la carpeta del proyecto.
3. Ejecuta:

```bash
streamlit run app_web_prediccion_candidato.py
```

Esto abrirá la app en tu navegador predeterminado.

## 📋 Ingreso de datos

La aplicación te pedirá ingresar:
- Nivel educativo
- Años de experiencia
- Puntajes en Python, SQL, Java y test técnico
- Número de certificaciones y proyectos open source
- Disponibilidad y edad

Con estos datos se calculará la probabilidad de selección usando el modelo entrenado.

---

Creado para fines académicos como parte del curso de Innovación y Transformación Digital.
