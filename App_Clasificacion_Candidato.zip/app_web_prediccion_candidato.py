
import streamlit as st
import pandas as pd
import joblib

st.set_page_config(page_title="Predicción de Selección de Candidatos", page_icon="🧠")
st.title("🧠 Clasificación de Candidatos Tecnológicos")
st.write("Esta aplicación permite predecir si un candidato sería seleccionado para entrevista técnica, usando un modelo de Machine Learning previamente entrenado.")

# Cargar modelo y scaler exportados
modelo = joblib.load("modelo_empleo_boosting.pkl")
scaler = joblib.load("scaler_empleo_boosting.pkl")

# Formulario de ingreso
st.subheader("📋 Ingrese los datos del candidato:")

with st.form("formulario_candidato"):
    nivel = st.selectbox("Nivel de Educación", ["Bachiller", "Tecnico", "Titulado", "Maestria"])
    experiencia = st.slider("Años de experiencia", 0, 20, 3)
    python = st.slider("Puntaje Python", 0, 100, 50)
    sql = st.slider("Puntaje SQL", 0, 100, 50)
    java = st.slider("Puntaje Java", 0, 100, 50)
    certs = st.slider("Número de certificaciones", 0, 10, 2)
    proyectos = st.slider("Proyectos open source", 0, 10, 1)
    test_online = st.slider("Puntaje en test técnico", 0, 100, 70)
    disponible = st.radio("¿Disponible de inmediato?", ["Sí", "No"]) == "Sí"
    edad = st.slider("Edad", 18, 60, 30)
    enviar = st.form_submit_button("Predecir")

if enviar:
    nuevo = {
        "experiencia_anios": experiencia,
        "python_score": python,
        "sql_score": sql,
        "java_score": java,
        "num_certificaciones": certs,
        "proyectos_open_source": proyectos,
        "puntaje_test_online": test_online,
        "disponibilidad_inmediata": int(disponible),
        "edad": edad,
        "nivel_educacion_Maestria": 1 if nivel == "Maestria" else 0,
        "nivel_educacion_Tecnico": 1 if nivel == "Tecnico" else 0,
        "nivel_educacion_Titulado": 1 if nivel == "Titulado" else 0
    }

    df_nuevo = pd.DataFrame([nuevo])
    df_nuevo_scaled = scaler.transform(df_nuevo)

    pred = modelo.predict(df_nuevo_scaled)[0]
    prob = modelo.predict_proba(df_nuevo_scaled)[0][1]

    st.markdown("---")
    if pred == 1:
        st.success(f"✅ El candidato **SERÍA SELECCIONADO** para entrevista. (Probabilidad: {prob:.2%})")
    else:
        st.error(f"❌ El candidato **NO sería seleccionado**. (Probabilidad: {prob:.2%})")
